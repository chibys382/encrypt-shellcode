#!/usr/bin/env python3
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import os
import sys

def get_filename():
    while True:
        filename = input("Inserte el nombre_archivo.bin para continuar: ").strip()
        if os.path.isfile(filename):
            return filename
        else:
            while True:
                retry = input("Archivo no encontrado. ¿Intentar nuevamente? [s/n]: ").strip().lower()
                if retry == "s":
                    break
                elif retry == "n":
                    print("Saliendo del programa.")
                    sys.exit(0)
                else:
                    print("Opción inválida. Solo se acepta 's' o 'n'.")

def encrypt_file(filename):
    key = os.urandom(16)
    iv = os.urandom(16)
    with open(filename, "rb") as f:
        data = f.read()
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(pad(data, AES.block_size))
    with open("payload_aes.h", "w") as f:
        f.write("unsigned char payload[] = {")
        f.write(",".join("0x{:02x}".format(b) for b in encrypted))
        f.write("};\n")
        f.write("unsigned int payload_len = {};\n\n".format(len(encrypted)))
        f.write("unsigned char key[16] = {")
        f.write(",".join("0x{:02x}".format(b) for b in key))
        f.write("};\n")
        f.write("unsigned char iv[16] = {")
        f.write(",".join("0x{:02x}".format(b) for b in iv))
        f.write("};\n")
    print(f"[✔] Archivo '{filename}' fue encriptado y guardado en 'payload_aes.h'.")

if __name__ == "__main__":
    archivo = get_filename()
    encrypt_file(archivo)
